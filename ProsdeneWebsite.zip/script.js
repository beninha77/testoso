
document.addEventListener('DOMContentLoaded', function() {
    console.log('Page loaded');
    // Adicione funcionalidades JavaScript adicionais aqui, se necessário
});
